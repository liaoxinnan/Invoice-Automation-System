from gmail_reader import get_gmail_service

service = get_gmail_service()

profile = service.users().getProfile(userId="me").execute()
print(f"Authenticated as: {profile['emailAddress']}")

result = service.users().labels().list(userId="me").execute()
for label in result.get("labels", []):
    print(f"  id={label['id']}  name={label['name']}")
