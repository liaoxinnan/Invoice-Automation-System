from __future__ import annotations

import os
import pandas as pd


def append_to_excel(row: dict, excel_path: str) -> None:
    if os.path.exists(excel_path):
        df = pd.read_excel(excel_path)
    else:
        df = pd.DataFrame()

    new_df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    new_df.to_excel(excel_path, index=False)