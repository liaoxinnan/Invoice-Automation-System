from __future__ import annotations

import re

from googleapiclient.discovery import build
from gmail_reader import get_credentials

COLUMNS = [
    "Receipt Date Stamped",
    "Date of Input",
    "Date of Document",
    "Due Date (If Applicable)",
    "Sender Name",
    "Document Nature",
    "Document Category",
    "Description",
    "Invoice #",
    "Tracking Number",
    "Invoice Amount",
    "GST (if any)",
    "Amount ($) Exc GST",
    "PIC",
    "URL LINK",
    "5MPO Classification",
]


def get_sheets_service():
    return build("sheets", "v4", credentials=get_credentials())


def append_to_sheet(row: dict, spreadsheet_id: str, sheet_name: str) -> int:
    """Append a row to the sheet and return the row number that was written."""
    service = get_sheets_service()
    values = [[row.get(col, "") for col in COLUMNS]]
    result = service.spreadsheets().values().append(
        spreadsheetId=spreadsheet_id,
        range=f"{sheet_name}!A1",
        valueInputOption="USER_ENTERED",
        insertDataOption="INSERT_ROWS",
        body={"values": values},
    ).execute()
    # Parse row number from updatedRange, e.g. "MIT!A42:O42" → 42
    updated_range = result.get("updates", {}).get("updatedRange", "")
    match = re.search(r"(\d+)$", updated_range)
    return int(match.group(1)) if match else 0


def protect_columns_a_to_p(spreadsheet_id: str, sheet_name: str) -> None:
    """Protect columns A-P so only specified editors can modify them.

    Run once to set up the protection.
    """
    service = get_sheets_service()

    # Look up the sheetId for the given sheet name
    meta = service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    sheet_id = None
    for s in meta["sheets"]:
        if s["properties"]["title"] == sheet_name:
            sheet_id = s["properties"]["sheetId"]
            break
    if sheet_id is None:
        raise ValueError(f"Sheet '{sheet_name}' not found")

    editors = [
        "training@clearsk.com",
        "finance.dept@clearsk.com",
        "nancy.liao@clearsk.com",
        "cheetat.then@clearsk.com",
        "alicia.lau@clearsk.com",
    ]

    request_body = {
        "requests": [
            {
                "addProtectedRange": {
                    "protectedRange": {
                        "range": {
                            "sheetId": sheet_id,
                            "startColumnIndex": 0,
                            "endColumnIndex": 16,
                        },
                        "description": "Columns A-P: agent + authorised editors only",
                        "warningOnly": False,
                        "editors": {"users": editors},
                    }
                }
            }
        ]
    }
    service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id, body=request_body
    ).execute()
    print(f"Protected columns A-P on '{sheet_name}'. Editors: {editors} + sheet owner.")


def update_gl_columns(
    spreadsheet_id: str, sheet_name: str, row_number: int, gl_data: dict
) -> None:
    """Write GL Account# Posted to column AA."""
    if not row_number or not gl_data.get("gl_code"):
        return
    service = get_sheets_service()
    gl_code = str(gl_data.get("gl_code", ""))
    gl_category = gl_data.get("gl_category", "")
    gl_value = f"{gl_code} - {gl_category}" if gl_category else gl_code
    service.spreadsheets().values().update(
        spreadsheetId=spreadsheet_id,
        range=f"{sheet_name}!AA{row_number}",
        valueInputOption="USER_ENTERED",
        body={"values": [[gl_value]]},
    ).execute()
