from __future__ import annotations

import os
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from gmail_reader import get_credentials

PARENT_FOLDER_NAME = "Finance Archive"

# Cache folder IDs so we don't query Drive repeatedly
_folder_cache: dict[str, str] = {}


def _get_drive_service():
    return build("drive", "v3", credentials=get_credentials())


def _find_folder_id(service, name: str, parent_id: str | None = None) -> str | None:
    query = f"name='{name}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
    if parent_id:
        query += f" and '{parent_id}' in parents"
    result = service.files().list(q=query, fields="files(id, name)").execute()
    files = result.get("files", [])
    return files[0]["id"] if files else None


def get_subfolder_id(subfolder_name: str) -> str | None:
    """Return the Drive folder ID for Finance Archive/{subfolder_name}."""
    cache_key = f"{PARENT_FOLDER_NAME}/{subfolder_name}"
    if cache_key in _folder_cache:
        return _folder_cache[cache_key]

    service = _get_drive_service()
    parent_id = _find_folder_id(service, PARENT_FOLDER_NAME)
    if not parent_id:
        raise ValueError(f"Google Drive folder '{PARENT_FOLDER_NAME}' not found.")

    folder_id = _find_folder_id(service, subfolder_name, parent_id)
    if not folder_id:
        raise ValueError(f"Subfolder '{subfolder_name}' not found inside '{PARENT_FOLDER_NAME}'.")

    _folder_cache[cache_key] = folder_id
    return folder_id


def upload_file(local_path: str, drive_subfolder: str) -> str:
    """Upload a file to Finance Archive/{drive_subfolder} and return a shareable view URL."""
    service = _get_drive_service()
    folder_id = get_subfolder_id(drive_subfolder)
    filename = os.path.basename(local_path)

    file_metadata = {
        "name": filename,
        "parents": [folder_id],
    }
    media = MediaFileUpload(local_path, mimetype="application/pdf", resumable=False)
    uploaded = service.files().create(
        body=file_metadata,
        media_body=media,
        fields="id"
    ).execute()

    file_id = uploaded["id"]

    # Restrict access to clearsk.com domain users only
    service.permissions().create(
        fileId=file_id,
        body={"type": "domain", "role": "reader", "domain": "clearsk.com"},
    ).execute()

    return f"https://drive.google.com/file/d/{file_id}/view"
