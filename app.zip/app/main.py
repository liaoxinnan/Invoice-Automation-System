from __future__ import annotations

import os

from gmail_reader import (
    list_messages, get_message, download_attachment,
    get_label_id_by_name, add_label_to_message,
    list_messages_finance, get_message_finance, download_attachment_finance,
    get_label_id_by_name_finance, add_label_to_message_finance,
)
from file_handler import move_and_rename_file
from sheets_writer import append_to_sheet, update_gl_columns
from drive_uploader import upload_file
from claude_agent import call_claude_agent

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMP_DIR = os.path.join(BASE_DIR, "data", "temp_attachments")
ARCHIVE_DIR = os.path.join(BASE_DIR, "data", "archive")
SPREADSHEET_ID = "1ZRHgAzUGbRkAowMeRq0ltURtt1Wvdj4QswC27HTe3TY"
SHEET_NAME = "MIT"


def choose_archive_folder(category: str) -> str:
    mapping = {
        "Stock Invoice":      "STOCK INVOICE",
        "Operation Invoice":  "OPERATION INVOICE",
        "Finance Invoice":    "FINANCE INVOICE",
        "SOA":                "SOA",
        "Government Letter":  "GOVERNMENT LETTER",
        "Loan":               "LOAN",
        "Rental":             "RENTAL",
        "Bank Letter":        "BANK LETTER",
        "Receipt":            "STOCK INVOICE",
        "Payment Request":    "OPERATION INVOICE",
        "Urgent Reply":       "OPERATION INVOICE",
        "Other":              "OTHERS",
    }
    folder = mapping.get(category, "OTHERS")
    return os.path.join(ARCHIVE_DIR, folder)




def _process_attachment(msg, att, download_fn):
    """Process a single PDF attachment: classify, upload, track."""
    temp_path = os.path.join(TEMP_DIR, att["filename"])
    download_fn(msg["message_id"], att["attachment_id"], temp_path)

    try:
        result = call_claude_agent(
            email_data=msg,
            original_filename=att["filename"],
            file_path=temp_path
        )
    except Exception as e:
        print(f"Error calling agent for {att['filename']}: {e}")
        return
    fields = result["fields"]
    new_filename = result.get("standard_filename", att["filename"])

    category = result.get("category", "Other")
    archive_folder = choose_archive_folder(category)
    final_path = move_and_rename_file(temp_path, archive_folder, new_filename)

    drive_subfolder = os.path.basename(archive_folder)
    try:
        file_url = upload_file(final_path, drive_subfolder)
    except Exception as e:
        print(f"Drive upload failed for {new_filename}: {e}")
        file_url = ""

    # Delete local file after successful Drive upload
    if file_url and os.path.exists(final_path):
        try:
            os.remove(final_path)
            print(f"  Deleted local file: {final_path}")
        except OSError as e:
            print(f"  Could not delete local file: {e}")

    row = {
        "Receipt Date Stamped":    msg.get("date", ""),
        "Date of Input":           msg.get("date", ""),
        "Date of Document":        fields.get("document_date", ""),
        "Due Date (If Applicable)": fields.get("due_date", ""),
        "Sender Name":             fields.get("vendor_name", ""),
        "Document Nature":         fields.get("document_nature", ""),
        "Document Category":       category,
        "Description":             fields.get("description", ""),
        "Invoice #":               fields.get("invoice_number", ""),
        "Tracking Number":         fields.get("tracking_number", ""),
        "Invoice Amount":          fields.get("amount", ""),
        "GST (if any)":            fields.get("gst", ""),
        "Amount ($) Exc GST":      fields.get("amount_excl_gst", ""),
        "PIC":                     "",
        "URL LINK":                file_url,
        "5MPO Classification":     result.get("fivempo_classification", ""),
    }

    try:
        row_number = append_to_sheet(row, SPREADSHEET_ID, SHEET_NAME)
        print("Saved tracker row:", row)
    except Exception as e:
        print(f"Sheets write failed: {e}")
        row_number = 0

    # Write GL columns (AL-AN) if Claude returned GL data
    gl_code = result.get("gl_code", "")
    gl_category = result.get("gl_category", "")
    if row_number and gl_code:
        gl_data = {"gl_code": gl_code, "gl_category": gl_category}
        try:
            update_gl_columns(SPREADSHEET_ID, SHEET_NAME, row_number, gl_data)
            print(f"  GL columns written: {gl_code} - {gl_category}")
        except Exception as e:
            print(f"  GL column write failed: {e}")


def main():
    os.makedirs(TEMP_DIR, exist_ok=True)

    AGENT_LABEL = "Agent-Processed"

    # --- Source 1: Scanner emails (training@ mailbox) ---
    label_id_training = get_label_id_by_name(AGENT_LABEL)
    scanner_msgs = list_messages(
        f"in:inbox has:attachment newer_than:7d from:Apeos C2561 -label:{AGENT_LABEL}",
        max_results=50
    )

    for item in scanner_msgs:
        msg = get_message(item["id"])
        print(f"[Scanner] Processing email: {msg['subject']}")

        for att in msg["attachments"]:
            if not att["filename"].lower().endswith(".pdf"):
                print(f"  Skipping non-PDF: {att['filename']}")
                continue
            _process_attachment(msg, att, download_attachment)

        add_label_to_message(msg["message_id"], label_id_training)
        print(f"Labelled email '{msg['subject']}' as {AGENT_LABEL}")

    # --- Source 2: Vendor emails (finance.dept@ mailbox) ---
    try:
        label_id_finance = get_label_id_by_name_finance(AGENT_LABEL)
    except Exception as e:
        print(f"WARNING: Could not get label from finance.dept mailbox: {e}")
        print("Skipping finance.dept emails. Create the 'Agent-Processed' label in finance.dept@clearsk.com Gmail.")
        label_id_finance = None

    if label_id_finance:
        vendor_msgs = list_messages_finance(
            f"in:inbox has:attachment newer_than:7d -label:{AGENT_LABEL}",
            max_results=50
        )

        for item in vendor_msgs:
            msg = get_message_finance(item["id"])
            print(f"[Vendor] Processing email: {msg['subject']}")

            for att in msg["attachments"]:
                if not att["filename"].lower().endswith(".pdf"):
                    print(f"  Skipping non-PDF: {att['filename']}")
                    continue
                _process_attachment(msg, att, download_attachment_finance)

            add_label_to_message_finance(msg["message_id"], label_id_finance)
            print(f"Labelled email '{msg['subject']}' as {AGENT_LABEL}")

if __name__ == "__main__":
    main()