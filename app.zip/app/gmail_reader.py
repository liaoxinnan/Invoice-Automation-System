
import base64
import os
from typing import Any, Dict, List

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CREDENTIALS_PATH = os.path.join(BASE_DIR, "credentials", "credentials.json")
TOKEN_PATH = os.path.join(BASE_DIR, "credentials", "token.json")
TOKEN_FINANCE_PATH = os.path.join(BASE_DIR, "credentials", "token_finance.json")


def get_gmail_service():
    creds = None
    if os.path.exists(TOKEN_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_PATH, SCOPES)
            creds = flow.run_local_server(port=0)

        with open(TOKEN_PATH, "w", encoding="utf-8") as token:
            token.write(creds.to_json())

    return build("gmail", "v1", credentials=creds)


def get_credentials():
    creds = None
    if os.path.exists(TOKEN_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_PATH, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(TOKEN_PATH, "w", encoding="utf-8") as token:
            token.write(creds.to_json())
    return creds


def get_finance_credentials():
    """Get OAuth2 credentials for finance.dept@clearsk.com (separate token)."""
    creds = None
    if os.path.exists(TOKEN_FINANCE_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_FINANCE_PATH, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            print("Please log in as finance.dept@clearsk.com in the browser window...")
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_PATH, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(TOKEN_FINANCE_PATH, "w", encoding="utf-8") as token:
            token.write(creds.to_json())
    return creds


def get_finance_gmail_service():
    return build("gmail", "v1", credentials=get_finance_credentials())


def list_messages(query: str, max_results: int = 10) -> List[Dict[str, Any]]:
    service = get_gmail_service()
    result = service.users().messages().list(userId="me", q=query, maxResults=max_results).execute()
    return result.get("messages", [])


def list_messages_finance(query: str, max_results: int = 10) -> List[Dict[str, Any]]:
    """List messages from the finance.dept@clearsk.com mailbox."""
    service = get_finance_gmail_service()
    result = service.users().messages().list(userId="me", q=query, maxResults=max_results).execute()
    return result.get("messages", [])


def _get_header(headers: List[Dict[str, str]], name: str) -> str:
    for h in headers:
        if h["name"].lower() == name.lower():
            return h["value"]
    return ""


def _extract_body(payload: Dict[str, Any]) -> str:
    if "parts" in payload:
        for part in payload["parts"]:
            if part.get("mimeType") == "text/plain" and "data" in part.get("body", {}):
                data = part["body"]["data"]
                return base64.urlsafe_b64decode(data).decode("utf-8", errors="ignore")
        for part in payload["parts"]:
            if "parts" in part:
                text = _extract_body(part)
                if text:
                    return text
    else:
        body = payload.get("body", {})
        if "data" in body:
            return base64.urlsafe_b64decode(body["data"]).decode("utf-8", errors="ignore")
    return ""


def get_message(message_id: str) -> Dict[str, Any]:
    service = get_gmail_service()
    msg = service.users().messages().get(userId="me", id=message_id, format="full").execute()

    payload = msg.get("payload", {})
    headers = payload.get("headers", [])

    attachments = []
    for part in payload.get("parts", []):
        filename = part.get("filename")
        body = part.get("body", {})
        attachment_id = body.get("attachmentId")
        if filename and attachment_id:
            attachments.append({
                "filename": filename,
                "attachment_id": attachment_id,
                "mime_type": part.get("mimeType", "")
            })

    return {
        "message_id": msg.get("id", ""),
        "thread_id": msg.get("threadId", ""),
        "sender": _get_header(headers, "From"),
        "to": _get_header(headers, "To"),
        "subject": _get_header(headers, "Subject"),
        "date": _get_header(headers, "Date"),
        "body": _extract_body(payload),
        "attachments": attachments
    }


def download_attachment(message_id: str, attachment_id: str, save_path: str) -> None:
    service = get_gmail_service()
    att = service.users().messages().attachments().get(
        userId="me",
        messageId=message_id,
        id=attachment_id
    ).execute()

    data = att["data"]
    file_data = base64.urlsafe_b64decode(data.encode("UTF-8"))

    with open(save_path, "wb") as f:
        f.write(file_data)


def get_label_id_by_name(label_name: str) -> str:
    service = get_gmail_service()
    result = service.users().labels().list(userId="me").execute()
    for label in result.get("labels", []):
        if label["name"].lower() == label_name.lower():
            return label["id"]
    raise ValueError(f"Gmail label '{label_name}' not found. Please create it in Gmail first.")


def add_label_to_message(message_id: str, label_id: str) -> None:
    service = get_gmail_service()
    service.users().messages().modify(
        userId="me",
        id=message_id,
        body={"addLabelIds": [label_id]}
    ).execute()


# --- Finance mailbox (finance.dept@clearsk.com) variants ---

def get_message_finance(message_id: str) -> Dict[str, Any]:
    """Get a message from the finance.dept mailbox."""
    service = get_finance_gmail_service()
    msg = service.users().messages().get(userId="me", id=message_id, format="full").execute()

    payload = msg.get("payload", {})
    headers = payload.get("headers", [])

    attachments = []
    for part in payload.get("parts", []):
        filename = part.get("filename")
        body = part.get("body", {})
        attachment_id = body.get("attachmentId")
        if filename and attachment_id:
            attachments.append({
                "filename": filename,
                "attachment_id": attachment_id,
                "mime_type": part.get("mimeType", "")
            })

    return {
        "message_id": msg.get("id", ""),
        "thread_id": msg.get("threadId", ""),
        "sender": _get_header(headers, "From"),
        "to": _get_header(headers, "To"),
        "subject": _get_header(headers, "Subject"),
        "date": _get_header(headers, "Date"),
        "body": _extract_body(payload),
        "attachments": attachments
    }


def download_attachment_finance(message_id: str, attachment_id: str, save_path: str) -> None:
    """Download an attachment from the finance.dept mailbox."""
    service = get_finance_gmail_service()
    att = service.users().messages().attachments().get(
        userId="me",
        messageId=message_id,
        id=attachment_id
    ).execute()

    data = att["data"]
    file_data = base64.urlsafe_b64decode(data.encode("UTF-8"))

    with open(save_path, "wb") as f:
        f.write(file_data)


def get_label_id_by_name_finance(label_name: str) -> str:
    """Get a label ID from the finance.dept mailbox."""
    service = get_finance_gmail_service()
    result = service.users().labels().list(userId="me").execute()
    for label in result.get("labels", []):
        if label["name"].lower() == label_name.lower():
            return label["id"]
    raise ValueError(f"Gmail label '{label_name}' not found in finance.dept mailbox. Please create it in Gmail first.")


def add_label_to_message_finance(message_id: str, label_id: str) -> None:
    """Add a label to a message in the finance.dept mailbox."""
    service = get_finance_gmail_service()
    service.users().messages().modify(
        userId="me",
        id=message_id,
        body={"addLabelIds": [label_id]}
    ).execute()