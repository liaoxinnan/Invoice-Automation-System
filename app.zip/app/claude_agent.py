from __future__ import annotations

import base64
import json
import os
import re
from datetime import datetime
from anthropic import Anthropic


client = Anthropic()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMPANY_MAPPING_PATH = os.path.join(BASE_DIR, "config", "company_mapping.json")
GL_MAPPING_PATH = os.path.join(BASE_DIR, "config", "gl_mapping.json")


def load_company_mapping() -> dict:
    if not os.path.exists(COMPANY_MAPPING_PATH):
        return {}
    with open(COMPANY_MAPPING_PATH, encoding="utf-8") as f:
        data = json.load(f)
    # Remove comment keys
    return {k: v for k, v in data.items() if not k.startswith("_")}


def load_gl_mapping() -> dict:
    if not os.path.exists(GL_MAPPING_PATH):
        return {}
    with open(GL_MAPPING_PATH, encoding="utf-8") as f:
        return json.load(f)


SUPPORTED_MIME = {
    ".pdf":  "application/pdf",
    ".png":  "image/png",
    ".jpg":  "image/jpeg",
    ".jpeg": "image/jpeg",
}


def encode_file(file_path: str) -> tuple[str, str] | None:
    """Return (base64_data, media_type) or None if unsupported."""
    ext = os.path.splitext(file_path)[1].lower()
    media_type = SUPPORTED_MIME.get(ext)
    if not media_type or not os.path.exists(file_path):
        return None
    with open(file_path, "rb") as f:
        return base64.standard_b64encode(f.read()).decode("utf-8"), media_type


def _build_gl_mapping_block() -> str:
    """Format the GL mapping table for inclusion in the Claude prompt."""
    gl_mapping = load_gl_mapping()
    if not gl_mapping:
        return "  (no GL mapping available)"
    lines = []
    for supplier_key, entry in gl_mapping.items():
        if isinstance(entry, list):
            for e in entry:
                ml = f" | Multi-line: {e['multi_line_logic']}" if e.get("multi_line_logic") else ""
                lines.append(f"  {supplier_key}: GL {e['gl_code']} ({e['gl_category']}) — Items: {e['item_description']}{ml}")
        else:
            ml = f" | Multi-line: {entry['multi_line_logic']}" if entry.get("multi_line_logic") else ""
            lines.append(f"  {supplier_key}: GL {entry['gl_code']} ({entry['gl_category']}) — Items: {entry['item_description']}{ml}")
    return "\n".join(lines)


def build_agent_prompt(email_data: dict, original_filename: str = "") -> str:
    company_mapping = load_company_mapping()
    mapping_lines = "\n".join(f'  "{full}": "{short}"' for full, short in company_mapping.items())
    mapping_block = mapping_lines if mapping_lines else "  (no entries yet — add them to config/company_mapping.json)"
    gl_block = _build_gl_mapping_block()

    return f"""
You are a finance email processing agent.

Analyze the email and attachment, then return JSON only.

Tasks:
1. Classify the document type into exactly one of these categories:
   - Stock Invoice: supplier invoice for goods, products, or inventory for resale/stock
   - Operation Invoice: utilities, maintenance, repairs, cleaning, logistics, professional services
   - Finance Invoice: bank charges, insurance premiums, accounting/audit fees, loan-related charges
   - SOA: statement of account
   - Government Letter: official letter from IRAS, MOM, CPF, HDB, BCA, or any statutory board
   - Loan: bank loan statements, hire purchase, financing instalment schedules
   - Rental: rental invoices or receipts from landlords
   - Bank Letter: letters from banks (debit advice, credit advice, fee notices, account notifications)
   - Receipt: proof of payment
   - Payment Request: payment request that is not a formal invoice
   - Other: does not fit any above
2. Extract finance fields from the attachment
3. Generate a standardized filename for the attachment
4. Prepare tracker row content
5. Determine the GL (General Ledger) account code using the GL mapping table below
6. Classify the document into exactly one 5MPO category based on the invoice content:
   - Manpower: staffing, wages, salaries, HR services, recruitment, training, worker-related costs
   - Material: consumables, supplies, stock, inventory, medical/treatment products, retail goods
   - Machines: equipment, devices, machinery, IT hardware, software licences, repair/maintenance of machines
   - Marketing, Management Office & Admin: advertising, branding, office supplies, admin services, legal, audit, accounting, consulting, management fees
   - Property: rental, lease, renovation, upkeep, building maintenance, depreciation of premises
   - Other Operating Expenses: utilities, logistics, transport, telecom, insurance, government fees, bank charges, anything not fitting the above
7. Identify the document nature — the specific type of document as it would be labelled on the document itself. Choose exactly one from:
   - Tax Invoice: a formal invoice issued for tax purposes
   - Instruction to Pay: any document instructing payment (GIRO, bank transfer instruction, payment advice)
   - Statement: account statement, statement of account, or billing summary
   - Notice: official notice, advisory, reminder, or notification letter
   - Contract: agreement, contract, service agreement, or terms document
   - Credit Note: a credit note issued to reduce a previously billed amount (e.g., returned goods, price adjustments, billing corrections, supplier rebates)
   - Debit Note: a debit note issued to request additional payment (e.g., additional charges, underbilling corrections, supplementary fees)
   - Receipt (Debit): proof of a payment you made — money going out (e.g., official receipt from a supplier, payment confirmation for an invoice you settled)
   - Receipt (Credit): proof of payment received by you — money coming in (e.g., patient receipt, customer payment confirmation, refund receipt)
   - Notice (Debit): notification of a deduction, charge, or amount being taken from you (e.g., bank debit advice, GIRO deduction notice, direct debit confirmation)
   - Notice (Credit): notification of an incoming credit or refund to you (e.g., bank credit advice, insurance reimbursement notice, rebate notification)
   - Letter: general correspondence that does not fit the above
   - Other: does not fit any of the above
   Write the chosen value into the "document_nature" field.

---

Email subject:
{email_data.get("subject", "")}

Sender:
{email_data.get("sender", "")}

Email body:
{email_data.get("body", "")}

Original attachment filename:
{original_filename}

The attachment is provided directly above as a document/image for you to read.

Note: If the email is from a vendor, bank, or government agency (not a document scanner),
use the email subject, sender, and body as additional context for classification and extraction.
The email metadata may contain information not present in the PDF itself.

---

Company short-name mapping (full legal name → short name for filenames):
{mapping_block}

Use this mapping to resolve the recipient company name found in the attachment's "Bill To" field.
If the name is not in the mapping, use the full name as-is (trimmed, uppercased).

---

GL Account Mapping Table (Supplier → GL Code, GL Category, typical items):
{gl_block}

GL Determination Rules:
- Match the vendor/supplier name from the document to the closest entry in the table above.
- If a supplier has "Multi-line" logic, read the invoice line items carefully and pick the GL code that best matches the items on THIS specific invoice.
- For intercompany entries (CSC/CSO/CMA etc.), match the entity code to the correct GL code as noted.
- If the supplier is not in the table, leave gl_code and gl_category empty.
- Return the single best-matching GL code. If the invoice genuinely has items spanning multiple GL codes, use the GL code for the highest-value line items and note the split in gl_notes.

---

Filename format rule:
  standard_filename = "YYMMDD - DOCUMENT_TYPE - SENDER - ADDRESSEE - TOPIC.ext"
  - YYMMDD: document date formatted as YYMMDD (e.g. 260308 for 2026-03-08). If not found, use 000000.
  - DOCUMENT_TYPE: the category value (e.g. OPERATION_INVOICE, STOCK_INVOICE, SOA, RECEIPT).
  - SENDER: vendor/supplier name from the document (spaces replaced with underscores, uppercase).
  - ADDRESSEE: short name resolved from the mapping above for the "Bill To" company (uppercase).
  - TOPIC: invoice number or reference if available; otherwise a short description of the document subject.
  - Use the original file extension.
  Example: 260308 - OPERATION_INVOICE - HIREMOP_PTE_LTD - CSH - INV141309.pdf

---

IMPORTANT: Return raw JSON only. Do not wrap in markdown code fences or add any explanation.

Return JSON in this exact format:
{{
  "category": "",
  "confidence": 0.0,
  "fields": {{
    "vendor_name": "",
    "invoice_number": "",
    "document_date": "",
    "due_date": "",
    "amount": "",
    "currency": "",
    "gst": "",
    "amount_excl_gst": "",
    "payment_terms": "",
    "po_number": "",
    "tracking_number": "",
    "receipt_short_name": "",
    "document_nature": "",
    "description": "",
    "remarks": ""
  }},
  "gl_code": "",
  "gl_category": "",
  "gl_notes": "",
  "fivempo_classification": "",
  "standard_filename": "",
  "review_needed": false,
  "notes": ""
}}
""".strip()


def extract_text_from_response(response) -> str:
    parts = []
    for block in response.content:
        if getattr(block, "type", None) == "text":
            parts.append(block.text)
    return "\n".join(parts).strip()


def _sanitize(value: str, max_len: int = 40) -> str:
    """Replace illegal filename characters with underscores and truncate."""
    value = value.upper().strip()
    value = re.sub(r"[^\w]", "_", value)       # keep only word chars (A-Z, 0-9, _)
    value = re.sub(r"_+", "_", value)           # collapse consecutive underscores
    value = value.strip("_")
    return value[:max_len]


def _format_yymmdd(date_str: str) -> str:
    """Parse a date string and return YYMMDD, or '000000' if unparseable."""
    if not date_str:
        return "000000"
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%Y%m%d", "%d %b %Y", "%d %B %Y"):
        try:
            return datetime.strptime(date_str.strip(), fmt).strftime("%y%m%d")
        except ValueError:
            continue
    return "000000"


def call_claude_agent(email_data: dict, original_filename: str, file_path: str) -> dict:
    prompt = build_agent_prompt(email_data, original_filename)

    # Build message content: text prompt + the actual file for Claude to read
    content = []
    encoded = encode_file(file_path)
    if encoded:
        data, media_type = encoded
        if media_type == "application/pdf":
            content.append({
                "type": "document",
                "source": {"type": "base64", "media_type": media_type, "data": data}
            })
        else:
            content.append({
                "type": "image",
                "source": {"type": "base64", "media_type": media_type, "data": data}
            })
    content.append({"type": "text", "text": prompt})

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=2000,
        temperature=0,
        messages=[{"role": "user", "content": content}]
    )

    raw_text = extract_text_from_response(response)

    # Strip markdown code fences if present (e.g. ```json ... ```)
    if raw_text.startswith("```"):
        raw_text = raw_text.strip("`")
        if raw_text.startswith("json"):
            raw_text = raw_text[4:]
        raw_text = raw_text.strip()

    try:
        result = json.loads(raw_text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Claude did not return valid JSON. Raw response: {raw_text}") from e

    # Resolve receipt_short_name in Python (case-insensitive) — don't rely on Claude for this
    mapping = load_company_mapping()
    bill_to_raw = result.get("fields", {}).get("receipt_short_name", "")
    short_name = next(
        (v for k, v in mapping.items() if k.lower() == bill_to_raw.lower()),
        bill_to_raw  # fallback: use whatever Claude returned
    )
    result["fields"]["receipt_short_name"] = short_name

    # Rebuild standard_filename with resolved short name
    date_part = _format_yymmdd(result["fields"].get("document_date", ""))
    doc_type = _sanitize(result.get("category", "") or "UNKNOWN")
    sender = _sanitize(result["fields"].get("vendor_name", "") or "UNKNOWN")
    addressee = _sanitize(short_name or "UNKNOWN")
    topic = _sanitize(
        result["fields"].get("invoice_number", "")
        or result["fields"].get("description", "")
        or "NO_REF",
        max_len=40,
    )
    ext = os.path.splitext(original_filename)[1].lower() or ".pdf"
    result["standard_filename"] = f"{date_part} - {doc_type} - {sender} - {addressee} - {topic}{ext}"

    return result
