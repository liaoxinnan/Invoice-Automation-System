from __future__ import annotations

import os
import fitz  # pymupdf
import pytesseract
from PIL import Image


def extract_pdf_text(file_path: str) -> str:
    text_parts = []
    try:
        doc = fitz.open(file_path)
        for page in doc:
            text_parts.append(page.get_text())
        doc.close()
    except Exception:
        return ""
    return "\n".join(text_parts).strip()


def extract_image_text(file_path: str) -> str:
    try:
        img = Image.open(file_path)
        return pytesseract.image_to_string(img)
    except Exception:
        return ""


def extract_pdf_text_ocr(file_path: str) -> str:
    """OCR fallback: render each PDF page as image and run tesseract."""
    text_parts = []
    try:
        doc = fitz.open(file_path)
        for page in doc:
            pix = page.get_pixmap(dpi=300)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            text_parts.append(pytesseract.image_to_string(img))
        doc.close()
    except Exception:
        return ""
    return "\n".join(text_parts).strip()


def extract_document_text(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        text = extract_pdf_text(file_path)
        if text.strip():
            return text
        # Scanned PDF — fall back to OCR
        return extract_pdf_text_ocr(file_path)

    if ext in [".png", ".jpg", ".jpeg"]:
        return extract_image_text(file_path)

    return ""