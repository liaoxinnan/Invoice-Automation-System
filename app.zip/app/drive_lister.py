"""List all files and folders inside the Finance Archive on Google Drive."""

from __future__ import annotations

import os
import sys

from googleapiclient.discovery import build
from gmail_reader import get_credentials

PARENT_FOLDER_NAME = "Finance Archive"
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_PATH = os.path.join(BASE_DIR, "data", "drive_file_listing.txt")


def _get_drive_service():
    return build("drive", "v3", credentials=get_credentials())


def _find_folder_id(service, name: str, parent_id: str | None = None) -> str | None:
    query = f"name='{name}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
    if parent_id:
        query += f" and '{parent_id}' in parents"
    result = service.files().list(q=query, fields="files(id, name)").execute()
    files = result.get("files", [])
    return files[0]["id"] if files else None


def _list_children(service, parent_id: str, mime_filter: str | None = None) -> list[dict]:
    """List all children of a folder, handling pagination."""
    query = f"'{parent_id}' in parents and trashed=false"
    if mime_filter:
        query += f" and mimeType='{mime_filter}'"

    all_files = []
    page_token = None
    while True:
        result = service.files().list(
            q=query,
            fields="nextPageToken, files(id, name, mimeType)",
            pageSize=1000,
            pageToken=page_token,
            orderBy="name",
        ).execute()
        all_files.extend(result.get("files", []))
        page_token = result.get("nextPageToken")
        if not page_token:
            break
    return all_files


def list_drive_structure():
    service = _get_drive_service()

    # Find parent folder
    parent_id = _find_folder_id(service, PARENT_FOLDER_NAME)
    if not parent_id:
        print(f"ERROR: Folder '{PARENT_FOLDER_NAME}' not found on Google Drive.")
        sys.exit(1)

    # Get all subfolders
    subfolders = _list_children(
        service, parent_id, mime_filter="application/vnd.google-apps.folder"
    )
    subfolders.sort(key=lambda f: f["name"])

    lines: list[str] = []
    lines.append(f"{PARENT_FOLDER_NAME}/  [id: {parent_id}]")

    total_files = 0

    for i, folder in enumerate(subfolders):
        is_last_folder = i == len(subfolders) - 1
        branch = "└── " if is_last_folder else "├── "
        indent = "    " if is_last_folder else "│   "

        # Get files inside this subfolder
        files = _list_children(service, folder["id"])
        # Separate sub-subfolders from files
        sub_subfolders = [f for f in files if f["mimeType"] == "application/vnd.google-apps.folder"]
        regular_files = [f for f in files if f["mimeType"] != "application/vnd.google-apps.folder"]
        total_files += len(regular_files)

        lines.append(f"{branch}{folder['name']}/ ({len(regular_files)} files)  [id: {folder['id']}]")

        # List sub-subfolders first
        for sf in sub_subfolders:
            lines.append(f"{indent}├── [FOLDER] {sf['name']}/  [id: {sf['id']}]")

        # List regular files
        for j, file in enumerate(regular_files):
            is_last_file = j == len(regular_files) - 1 and not sub_subfolders
            file_branch = "└── " if is_last_file else "├── "
            lines.append(f"{indent}{file_branch}{file['name']}  [id: {file['id']}]")

    lines.append("")
    lines.append(f"Total: {total_files} files across {len(subfolders)} folders")

    output = "\n".join(lines)

    # Print to console (handle unicode on Windows)
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(output)

    # Save to file
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(output)
    print(f"\nSaved to: {OUTPUT_PATH}")


if __name__ == "__main__":
    list_drive_structure()
