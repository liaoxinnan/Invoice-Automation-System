from anthropic import Anthropic

client = Anthropic()

response = client.messages.create(
    model="claude-sonnet-4-5",
    max_tokens=300,
    messages=[
        {"role": "user", "content": "Reply with valid JSON only: {\"status\":\"ok\"}"}
    ]
)

print(response)