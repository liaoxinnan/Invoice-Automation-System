from __future__ import annotations

import os
import shutil


def move_and_rename_file(src_path: str, dst_folder: str, new_filename: str) -> str:
    os.makedirs(dst_folder, exist_ok=True)
    dst_path = os.path.join(dst_folder, new_filename)
    shutil.move(src_path, dst_path)
    return dst_path